# REST API RENIEC SUNAT
Esta es una pequeña REST Api para las conexiones a Reniec y Sunat con NodeJS,Express,MySQL y usando como autenticacion JSON-web-token.
